# mc_plugin_strcreator/__init__.py
# Empty init file for package
