# mc-plugin-str-creator

A Python CLI tool to scaffold a basic Minecraft plugin folder structure with:

- `pom.xml`
- `Main.java`
- `plugin.yml`
- `config.yml`
- `messages.yml`